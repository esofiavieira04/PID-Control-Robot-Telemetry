/**
 * Config.h
 * Centralized system configuration parameters 
 */

#ifndef CONFIG_H
#define CONFIG_H

// ============================================
// OPERATIONAL MODE CONFIGURATION
// ============================================
/**
 * Active operational mode selector
 * Change this value to select robot behavior
 * 
 * Available modes:
 * 0  - Diagnostic mode (sensor testing)
 * 1  - Line following
 * 2  - Obstacle avoidance
 * 3  - Test motors basic
 * 4  - Forward and backward 30cm
 * 5  - Rocking
 * 6  - Calibration
 * 7  - Line following with obstacle avoidance - stop and wait
 */
#define ROBOT_MODE 1

// ============================================
// ENCODER CALIBRATION PARAMETERS
// ============================================

#define WHEEL_DIAMETER_CM 7.0  ///< Wheel diameter in centimeters
#define MOTOR_RIGHT_FACTOR 1.10  ///< Right motor speed adjustment factor due to weird hardware variance
#define ENCODER_PPR 1920 ///< Encoder pulses per revolution

// ============================================
// HARDWARE PIN ASSIGNMENTS
// ============================================
#define MOTOR_L_IN1 2  ///< Left motor forward control
#define MOTOR_L_IN2 3  ///< Left motor reverse control
#define MOTOR_R_IN3 5  ///< Right motor forward control
#define MOTOR_R_IN4 6  ///< Right motor reverse control

#define ENCODER_L_A 8   ///< Left encoder channel A
#define ENCODER_L_B 9   ///< Left encoder channel B
#define ENCODER_R_A 10  ///< Right encoder channel A
#define ENCODER_R_B 11  ///< Right encoder channel B

const uint8_t LINE_PINS[8] = {
  28, 27, 26, 22, 19, 18, 17, 16
};
#define LINE_IR_ENABLE 1  ///< IR emitter enable pin

#define SONAR_TRIG 12  ///< Ultrasonic trigger pin
#define SONAR_ECHO 13  ///< Ultrasonic echo pin

#define IMU_SDA 20  ///< I2C data line
#define IMU_SCL 21  ///< I2C clock line

// ============================================
// MOTION CONTROL PARAMETERS
// ============================================
#define DEFAULT_SPEED 180
#define DEFAULT_TURN_SPEED 150

// ============================================
// PID CONTROLLER TUNING
// ============================================

#define LINE_KP 5      ///< Proportional gain
#define LINE_KI 0  ///< Integral gain
#define LINE_KD 70      ///< Derivative gain

#define IMU_CORRECTION_GAIN 2.0 ///< IMU correction gain for straight movement

// ============================================
// SAFETY THRESHOLDS
// ============================================
#define OBSTACLE_THRESHOLD 20.0
#define MAX_MOTOR_SPEED 255

#endif 