/*
 * Sonar.h
 * HC-SR04 ultrasonic sensor for obstacle detection
 */

#ifndef SONAR_H
#define SONAR_H

#include <Arduino.h>

class Sonar {
private:
  uint8_t trigPin;
  uint8_t echoPin;
  unsigned long lastMeasurement;
  float lastDistance;
  const unsigned long measureInterval = 50; // ms

public:
  Sonar(uint8_t trig, uint8_t echo): trigPin(trig), echoPin(echo), lastMeasurement(0), lastDistance(0) {}
  
  // Initialization
  void init() {
    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);
    digitalWrite(trigPin, LOW);
    Serial.println("[Sonar] Initialized");
  }
  
  // Measure distance in centimeters
  float measureDistance() {
    // Rate limiting
    if (millis() - lastMeasurement < measureInterval) {
      return lastDistance;
    }
    
    // Trigger pulse
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);
    
    // Read echo pulse
    unsigned long duration = pulseIn(echoPin, HIGH, 30000); // 30ms timeout
    
    if (duration == 0) {
      lastDistance = 400.0; // No echo = far away
    } else {
      lastDistance = duration * 0.034 / 2.0; // Speed of sound: 340 m/s
    }
    
    lastMeasurement = millis();
    return lastDistance;
  }
  
  // Check if obstacle within threshold
  bool obstacleDetected(float threshold = 20.0) {
    return (measureDistance() < threshold);
  }
  
  // Get last measured distance without new measurement
  float getLastDistance() {
    return lastDistance;
  }
};

#endif