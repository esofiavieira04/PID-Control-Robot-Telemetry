/*
 * IMU.h
 * MPU6050 accelerometer + gyroscope for orientation tracking
 */

#ifndef IMU_H
#define IMU_H

#include <Arduino.h>
#include <Wire.h>

// MPU6050 I2C address and registers
#define MPU6050_ADDR 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_GYRO_XOUT_H 0x43

class IMU {
private:
// Hardware pins
  uint8_t sdaPin;
  uint8_t sclPin;
  
// Orientation data
  float yaw, pitch, roll;
  float gyroX, gyroY, gyroZ;
  float accelX, accelY, accelZ;
 
// Timing
  unsigned long lastUpdate;
 
  // Read raw data from MPU6050
  void readRawData(uint8_t reg, int16_t* data, uint8_t count) {
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(reg);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU6050_ADDR, count * 2);
    
    for (uint8_t i = 0; i < count; i++) {
      data[i] = (Wire.read() << 8) | Wire.read();
    }
  }

public:
// Constructor
  IMU(uint8_t sda, uint8_t scl): sdaPin(sda), sclPin(scl), yaw(0), pitch(0), roll(0), lastUpdate(0) {}
  
// Initialization
  void init() {
    Wire.setSDA(sdaPin);
    Wire.setSCL(sclPin);
    Wire.begin();
    
    // Wake up MPU6050
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(MPU6050_PWR_MGMT_1);
    Wire.write(0x00);
    Wire.endTransmission();
    
    // Allow time to stabilize
    delay(100);
    lastUpdate = millis();
    Serial.println("[IMU] MPU6050 initialized");
  }
  
  // Update orientation data
  void update() {
    int16_t rawData[6];
    
    // Read accelerometer
    readRawData(MPU6050_ACCEL_XOUT_H, rawData, 3);
    accelX = rawData[0] / 16384.0;
    accelY = rawData[1] / 16384.0;
    accelZ = rawData[2] / 16384.0;
    
    // Read gyroscope
    readRawData(MPU6050_GYRO_XOUT_H, rawData, 3);
    gyroX = rawData[0] / 131.0;
    gyroY = rawData[1] / 131.0;
    gyroZ = rawData[2] / 131.0;
    
    // Calculate time delta
    unsigned long now = millis();
    float dt = (now - lastUpdate) / 1000.0;
    lastUpdate = now;
    
    // Integrate gyro for orientation (simple integration)
    yaw += gyroZ * dt;
    pitch += gyroY * dt;
    roll += gyroX * dt;
    
    // Complementary filter with accelerometer (for pitch and roll)
    float accelPitch = atan2(accelY, accelZ) * 180.0 / PI;
    float accelRoll = atan2(accelX, accelZ) * 180.0 / PI;
    
    pitch = 0.98 * pitch + 0.02 * accelPitch; // Complementary filter
    roll = 0.98 * roll + 0.02 * accelRoll; // Complementary filter
  }
  
  // Getters for orientation
  float getYaw(){
     update(); 
     return yaw; }
  
  // Getter for pitch
  float getPitch(){
     update(); 
     return pitch; }

  // Getter for roll
  float getRoll(){
     update(); 
     return roll; }
  
  // Reset yaw to zero
  void resetYaw(){ 
    yaw = 0;}
  
  // Get raw acceleration and gyro data
  void getAcceleration(float& x, float& y, float& z) {
    x = accelX;
    y = accelY;
    z = accelZ;
  }
  
  // Get raw gyro data
  void getGyro(float& x, float& y, float& z) {
    x = gyroX;
    y = gyroY;
    z = gyroZ;
  }
};

#endif