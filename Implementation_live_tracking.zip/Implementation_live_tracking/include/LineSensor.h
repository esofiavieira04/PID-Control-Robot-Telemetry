/*
 * LineSensor.h 
 * Digital Mode 
 */

#ifndef LINE_SENSOR_H
#define LINE_SENSOR_H

#include <Arduino.h>

// Define the digital value that indicates line detection
#define LINE_DETECTED_VALUE HIGH 

class LineSensor {
private:
  uint8_t* pins;
  uint8_t numSensors;
  uint8_t irEnablePin;

public:
// Constructor
  LineSensor(const uint8_t* sensorPins, uint8_t count, uint8_t irPin):
   numSensors(count), irEnablePin(irPin) { 
    pins = new uint8_t[count];
    for (uint8_t i = 0; i < count; i++) {
      pins[i] = sensorPins[i];
    }
  }
  
  // Destructor
  ~LineSensor() {
    delete[] pins;
  }
  
  // Initialization
  void init() {
    for (uint8_t i = 0; i < numSensors; i++) {
      pinMode(pins[i], INPUT);
    }
    pinMode(irEnablePin, OUTPUT);
    digitalWrite(irEnablePin, HIGH); 
    Serial.println("[LineSensor] Initialized.");
  }
  
  // Get raw analog values (simulated as digital here)
  void getRawAnalogValues(uint16_t* values) {
    for (uint8_t i = 0; i < numSensors; i++) {
      values[i] = digitalRead(pins[i]) == LINE_DETECTED_VALUE ? 1000 : 0;
    }
  }
  
  // Read line position
  int readPosition() {
    long weightedSum = 0;
    int totalActive = 0;
    
    for (uint8_t i = 0; i < numSensors; i++) {
      if (digitalRead(pins[i]) == LINE_DETECTED_VALUE) {
        weightedSum += (long)i * 1000;
        totalActive++;
      }
    }
    
    if (totalActive == 0) return -1;
    return weightedSum / totalActive;
  }

  // Calibration (not needed in digital mode)
  void calibrate() {
    Serial.println("[LineSensor] Skipped.");
  }
  
  // Read raw sensor states as bitmask
  uint8_t readRaw() {
    uint8_t result = 0;
    for (uint8_t i = 0; i < numSensors; i++) {
      if (digitalRead(pins[i]) == LINE_DETECTED_VALUE) { 
        result |= (1 << i);
      }
    }
    return result;
  }


  // Check if all sensors are off the line
  bool isOffLine() {
    return (readRaw() == 0);
  }
};

#endif
