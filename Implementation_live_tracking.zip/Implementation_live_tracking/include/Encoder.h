/*
 * Encoder.h
 * Quadrature encoder for wheel rotation measurement
 */

#ifndef ENCODER_H
#define ENCODER_H

#include <Arduino.h>

class Encoder {
private:
// Hardware pins
  uint8_t pinA;
  uint8_t pinB;

// Variables to track state
  volatile long count;// Pulse count
  volatile uint8_t lastState;// Last state of encoder pins
  
// Static members for ISR handling
  static Encoder* instances[4];// Support up to 4 encoders
  static uint8_t instanceCount;// Number of encoder instances
  uint8_t instanceIndex;// Index of this instance
  
 // ISR Handlers 
  static void isrHandler0(){ 
    instances[0]->handleInterrupt();
  }
  static void isrHandler1(){
    instances[1]->handleInterrupt();
  }
  static void isrHandler2(){ 
    instances[2]->handleInterrupt(); 
  }
  static void isrHandler3(){
   instances[3]->handleInterrupt(); 
  }
  
// Interrupt handling logic
void handleInterrupt() {
    int sA = digitalRead(pinA); 
    int sB = digitalRead(pinB); 
    
   
    if (sA == HIGH) {
        (sB == LOW) ? count++ : count--;
    }
}

public:
// Constructor
  Encoder(uint8_t a, uint8_t b): pinA(a), pinB(b), count(0), lastState(0){
    if (instanceCount < 4){
      instanceIndex = instanceCount; 
      instances[instanceCount++] = this;
    }
  }
  
// Initialization
  void init(){
    pinMode(pinA, INPUT_PULLUP);
    pinMode(pinB, INPUT_PULLUP);
    
    lastState = (digitalRead(pinA) << 1) | digitalRead(pinB);
    
    // Attach interrupt
    void (*isr)() = nullptr;
    switch (instanceIndex) {
      case 0: 
        isr = isrHandler0; 
        break;
      case 1: 
        isr = isrHandler1; 
        break;
      case 2: 
        isr = isrHandler2; 
        break;
      case 3:  
       isr = isrHandler3; 
       break;
    }
    
    if (isr) {
      attachInterrupt(digitalPinToInterrupt(pinA), isr, CHANGE); // CHANGE for both edges
    }
    
    Serial.println("[Encoder] Initialized on pins " + String(pinA) + ", " + String(pinB));
  }
  // Get current pulse count
  long getCount() {
    noInterrupts();
    long c = count;
    interrupts();
    return c;
  }
  // Reset count to zero
  void reset() {
    noInterrupts();
    count = 0;
    interrupts();
  }
  
  

  // Calculate distance traveled in cm
  float getDistance(float wheelDiameter = 6.5, int ppr = 1920) {
    long c = getCount();
    Serial.print("[Encoder] Count: "); Serial.println(c);
    float circumference = PI * wheelDiameter;
    Serial.print("[Encoder] Circumference: "); Serial.println(circumference);
  
  return (c * circumference) / (ppr * 2); // Two pulses per revolution
}

};

// Static member initialization
Encoder* Encoder::instances[4] = {nullptr, nullptr, nullptr, nullptr};
uint8_t Encoder::instanceCount = 0;

#endif