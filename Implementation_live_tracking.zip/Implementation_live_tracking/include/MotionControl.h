/*
 * MotionControl.h
 * High-level motion control functions
 */

#ifndef MOTION_CONTROL_H
#define MOTION_CONTROL_H

#include "HardwareSetup.h"
#include "Config.h"

// ============================================
// MOVE FORWARD WITH DISTANCE CONTROL
// ============================================
void moveDistance(Hardware& hw, float targetCm, int speed, bool useIMU) {
    hw.encoderLeft.reset();
    hw.encoderRight.reset();
    
    float distanceTraveled = 0;
    while (abs(distanceTraveled) < targetCm) { 
        
        float distL = abs(hw.encoderLeft.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
        float distR = abs(hw.encoderRight.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
        
        distanceTraveled = (distL + distR) / 2.0;

        hw.motors.setSpeed(speed, (MOTOR_RIGHT_FACTOR*speed));
        
        
        Serial.print("Dist: "); Serial.println(distanceTraveled);
        
        delay(10);
    }
    hw.motors.stop();
}

// ============================================
// MOVE BACKWARD WITH DISTANCE CONTROL
// ============================================
void moveBackwardDistance(Hardware& hw, float targetCm, int speed = DEFAULT_SPEED, bool useIMU = true) {
 
    hw.encoderLeft.reset();
    hw.encoderRight.reset();
    
    float distanceTraveled = 0;
    while (abs(distanceTraveled) < targetCm) { 
        
        float distL = abs(hw.encoderLeft.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
        float distR = abs(hw.encoderRight.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
        
        distanceTraveled = (distL + distR) / 2.0;

        hw.motors.setSpeed(-speed, -speed);
        
        
        Serial.print("Dist: "); Serial.println(distanceTraveled);
        
        delay(10);
    }
    hw.motors.stop();
}

// ============================================
// TURN BY ANGLE (USING IMU)
// ============================================
void turnByAngle(Hardware& hw, float targetAngle, int speed = DEFAULT_TURN_SPEED) {
  hw.imu.resetYaw();
  
  Serial.print("Turning ");
  Serial.print(targetAngle);
  Serial.println("°");
  
  unsigned long startTime = millis();
  
  while (abs(hw.imu.getYaw() - targetAngle) > 2.0) {  // 2° tolerance
    hw.imu.update();
    float currentAngle = hw.imu.getYaw();
    
    if (currentAngle < targetAngle) {
      hw.motors.turnRight(speed);
    } else {
      hw.motors.turnLeft(speed);
    }
    
    // Timeout after 5 seconds
    if (millis() - startTime > 5000) {
      Serial.println("⚠ Turn timeout!");
      break;
    }
    
    delay(10);
  }
  
  hw.motors.stop();
  Serial.print("✓ Final angle: ");
  Serial.print(hw.imu.getYaw());
  Serial.println("°");
}

// ============================================
// EMERGENCY STOP
// ============================================
void emergencyStop(Hardware& hw) {
  hw.motors.stop();
  Serial.println("\n!!! EMERGENCY STOP !!!\n");
  delay(1000);
}

// ============================================
// SMOOTH ACCELERATION
// ============================================
void smoothAccelerate(Hardware& hw, int targetSpeed, int steps = 20, int delayMs = 50) {
  int currentSpeed = 0;
  int increment = targetSpeed / steps;
  
  for (int i = 0; i <= steps; i++) {
    currentSpeed = i * increment;
    hw.motors.setSpeed(currentSpeed, currentSpeed);
    delay(delayMs);
  }
}

// ============================================
// SMOOTH DECELERATION
// ============================================
void smoothDecelerate(Hardware& hw, int initialSpeed, int steps = 20, int delayMs = 50) {
  int decrement = initialSpeed / steps;
  
  for (int i = steps; i >= 0; i--) {
    int currentSpeed = i * decrement;
    hw.motors.setSpeed(currentSpeed, currentSpeed);
    delay(delayMs);
  }
  
  hw.motors.stop();
}

#endif