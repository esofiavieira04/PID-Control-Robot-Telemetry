/*
 * LiveTracking.h - Real-time telemetry and tracking web server
 * 
 */

#ifndef LIVE_TRACKING_H
#define LIVE_TRACKING_H

#include <WiFi.h>
#include <WebServer.h>
#include "HardwareSetup.h"
#include "Config.h"

class LiveTracking {
private:
// Using WebServer from WebServer.h
    WebServer server;
    const char* ssid = "Galaxy_Eduarda"; 
    const char* password = "ups123ups2"; 

    // Handle /data endpoint for telemetry
    void handleData() {
        extern Hardware hw;
        float currentSonar = hw.sonar.measureDistance();
        hw.imu.update();
        
        // Get distances from encoders
        float cmL = hw.encoderLeft.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR);
        float cmR = hw.encoderRight.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR);

        // Construct JSON response
        String json = "{";
        json += "\"sonar\":" + String(currentSonar) + ",";
        json += "\"yaw\":"   + String(hw.imu.getYaw()) + ",";
        json += "\"distL\":" + String(cmL) + ",";
        json += "\"distR\":" + String(cmR) + ",";
        json += "\"line\":"  + String(hw.lineSensor.readRaw());
        json += "}";
        server.send(200, "application/json", json);
    }
// Handle root endpoint for HTML page
    void handleRoot() {
        String html = R"rawliteral(
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>CORE INTELLIGENCE OS</title>
    <style>
        :root { --neon-blue: #00f2ff; --bg-dark: #050505; --panel-bg: #0d0d0d; }
        body { background: var(--bg-dark); color: white; font-family: 'Courier New', monospace; margin: 0; padding: 20px; display: flex; flex-direction: column; height: 95vh; overflow: hidden;}
        header { border-bottom: 2px solid var(--neon-blue); padding-bottom: 10px; margin-bottom: 20px; text-align: center; color: var(--neon-blue); font-weight: bold; letter-spacing: 5px; }
        .main-container { display: grid; grid-template-columns: 320px 1fr; gap: 20px; flex-grow: 1; }
        .side-panel { display: flex; flex-direction: column; gap: 15px; }
        .widget { background: var(--panel-bg); border-right: 4px solid var(--neon-blue); padding: 15px; border-radius: 4px; }
        .widget-title { font-size: 10px; color: #888; text-transform: uppercase; margin-bottom: 5px; }
        .widget-value { font-size: 24px; color: var(--neon-blue); text-shadow: 0 0 10px rgba(0,242,255,0.5); }
        .map-section { position: relative; background: var(--panel-bg); border: 1px solid #333; overflow: hidden; border-radius: 8px; }
        canvas { background-image: radial-gradient(#1a1a1a 1px, transparent 1px); background-size: 40px 40px; }
        .bin-line { font-size: 18px; letter-spacing: 4px; color: #444; }
        .bin-active { color: var(--neon-blue); font-weight: bold; }
    </style>
</head>
<body>
    <header> ⚛ CORE INTELLIGENCE OS </header>
    <div class="main-container">
        <aside class="side-panel">
            <div class="widget">
                <div class="widget-title">PROXIMIDADE</div>
                <div class="widget-value"><span id="valSonar">0.0</span> <small>cm</small></div>
            </div>
            <div class="widget">
                <div class="widget-title">DISTÂNCIA L</div>
                <div class="widget-value"><span id="valL">0.0</span> <small>cm</small></div>
            </div>
            <div class="widget">
                <div class="widget-title">DISTÂNCIA R</div>
                <div class="widget-value"><span id="valR">0.0</span> <small>cm</small></div>
            </div>
            <div class="widget">
                <div class="widget-title">SENSORES LINHA</div>
                <div id="valLine" class="bin-line">00000000</div>
            </div>
            <button onclick="resetMap()" style="background:none; border:1px solid var(--neon-blue); color:var(--neon-blue); padding:8px; cursor:pointer; font-family:inherit; margin-top:10px;">RESET MAPA</button>
        </aside>
        <section class="map-section">
            <canvas id="trackCanvas"></canvas>
        </section>
    </div>
    <script>
        const canvas = document.getElementById('trackCanvas');
        const ctx = canvas.getContext('2d');
        let posX, posY;

        function resize() {
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
            resetMap();
        }

        function resetMap() {
            posX = canvas.width / 2;
            posY = canvas.height / 2;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        window.onresize = resize; resize();

        let lastDistTotal = 0;
        ctx.strokeStyle = '#00f2ff';
        ctx.lineWidth = 3; // Linha mais fina para escala menor
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#00f2ff';
        ctx.lineCap = 'round';

        async function update() {
            try {
                const res = await fetch('/data');
                const d = await res.json();
                
                document.getElementById('valSonar').innerText = d.sonar.toFixed(1);
                document.getElementById('valL').innerText = d.distL.toFixed(1);
                document.getElementById('valR').innerText = d.distR.toFixed(1);

                let binary = d.line.toString(2).padStart(8, '0');
                document.getElementById('valLine').innerHTML = binary.split('').map(b => b === '1' ? '<span class="bin-active">1</span>' : '0').join('');

                // ESCALA 4X MENOR: Multiplicador em 10.0
                let currentTotal = (d.distL + d.distR) / 2;
                let delta = (currentTotal - lastDistTotal) * 10.0; 
                
                let angle = (d.yaw - 90) * (Math.PI / 180);

                if (Math.abs(delta) > 0.1) {
                    ctx.beginPath();
                    ctx.moveTo(posX, posY);

                    
                    posX -= delta * Math.cos(angle); 
                    posY += delta * Math.sin(angle);

                    ctx.lineTo(posX, posY);
                    ctx.stroke();
                    
                    lastDistTotal = currentTotal;
                }
            } catch (e) {}
        }
        setInterval(update, 50); 
    </script>
</body>
</html>
)rawliteral";
        server.send(200, "text/html", html);
    }

public:
// Constructor
    LiveTracking() : server(80) {}
    void init() {
        WiFi.begin(ssid, password);
        while (WiFi.status() != WL_CONNECTED) { delay(500); }
        server.on("/", std::bind(&LiveTracking::handleRoot, this));
        server.on("/data", std::bind(&LiveTracking::handleData, this));
        server.begin();
    }
    // Call in main loop
    void update() { server.handleClient(); }
};

#endif