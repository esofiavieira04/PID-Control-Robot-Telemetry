#ifndef MODES_H
#define MODES_H

#include "HardwareSetup.h"
#include "MotionControl.h"
#include "Config.h"


// ============================================
// MODE 0: DIAGNOSTIC
// ============================================
void modeDiagnostic(Hardware& hw) {
  static bool firstRun = true;
  static unsigned long lastPrint = 0;

  // Run diagnostics only once
  if (firstRun) {
    hw.diagnosticCheck(); 
    firstRun = false;
    Serial.println(F("=== Real time monitoring ==="));
  }

// Periodic status printout 
  if (millis() - lastPrint > 500) {
    hw.imu.update(); 
    
    Serial.print(F("Sonar:")); 
    Serial.print(hw.sonar.measureDistance(), 1);
    Serial.print(F("\n cm | L:")); 
    Serial.print(hw.encoderLeft.getCount());
    Serial.print(F(" R:")); 
    Serial.print(hw.encoderRight.getCount());
    Serial.print(F(" | Line:")); 
    Serial.println(hw.lineSensor.readRaw(), BIN);
    
    lastPrint = millis();
  }

  hw.motors.stop();
}

// ============================================
// MODE 1: LINE FOLLOWING
// ============================================
static float lastError = 0;
static float error = 0;
void modeLineFollow(Hardware& hw) {
  
  uint8_t raw = hw.lineSensor.readRaw(); 
  bool lineFound = (raw != 0);

  if (lineFound) {
    int activeSensors = 0;
    for (int i = 0; i < 8; i++) if ((raw >> i) & 1) activeSensors++;
    
   //Error calculation
    if (activeSensors > 5) {
      error = lastError; // Maintain last error if too many sensors active
    } else {
      //Error based on sensor positions
      if (raw & 0b10000000)      
        error = -4.0; 
      else if (raw & 0b00000001) 
        error = 4.0;
      else if (raw & 0b01000000) 
        error = -2.5;
      else if (raw & 0b00000010) 
        error = 2.5;
      else if (raw & 0b00110000) 
        error = -1.0;
      else if (raw & 0b00001100) 
        error = 1.0;
      else if (raw & 0b00011000) 
        error = 0;
      else 
        error = lastError; // Fallback
    }

    //PID 
    float correction = (LINE_KP * error) + (LINE_KD * (error - lastError));

    // Adjust base speed dynamically
    // Slow down when error is indicates a sharp turn, stay at 110 when error is 0
    int dynamicBaseSpeed = 125 - (abs(error) * 15); 
    dynamicBaseSpeed = constrain(dynamicBaseSpeed, 50, 150); 

    // Calculate motor speeds
    int leftSpeed = constrain(dynamicBaseSpeed + correction, -80, 160);
    int rightSpeed = constrain(dynamicBaseSpeed - correction, -80, 160);

    // Set motor speeds 
    hw.motors.setSpeed(leftSpeed,rightSpeed);
    lastError = error;

  } else {
    // If line lost, spin in direction of last error - useful for sharp turns
    if (lastError > 0)      
      hw.motors.setSpeed(70, -70);
    else if (lastError < 0) 
      hw.motors.setSpeed(-70, 70);
    else 
      hw.motors.stop();

  }
}

// ============================================
// MODE 2: LINE FOLLOWING WITH OBSTACLE AVOIDANCE
// ============================================
void modeLineFollowingWithObstacles(Hardware& hw) {
 
  // State machine states
  static enum State {
    FOLLOWING_LINE,
    SLIGHT_LEFT,     
    BYPASS_FORWARD,   
    SLIGHT_RIGHT,    
    ADVANCE_AFTER_RIGHT,  
    SEARCHING_LINE     
  } state = FOLLOWING_LINE;

  // Static variables for state management
  static float lastError = 0;
  static unsigned long stateStartTime = 0;
  static unsigned long lastObstacleTime = 0;

  // Constants
  const float OBSTACLE_DISTANCE = 20.0;         // cm 
  const unsigned long OBSTACLE_COOLDOWN = 1000; // ms
  const int SLIGHT_TURN_TIME = 800;             // ms 
  const int SEARCH_TIME = 5000;                 // ms
  const int BYPASS_MAX_TIME = 3000;             // ms 
 
  // Read sensors
  uint8_t raw = hw.lineSensor.readRaw();
  float distance = hw.sonar.measureDistance();

  // Obstacle detection logic
  bool obstacleAhead = false;
  if (state == FOLLOWING_LINE) {
    obstacleAhead = (distance < OBSTACLE_DISTANCE &&
                     distance > 2.0 &&
                     millis() - lastObstacleTime > OBSTACLE_COOLDOWN);
  }

  // Line sensor processing
  bool lineFound = (raw != 0);
  int activeSensors = 0;
  if (lineFound) {
    for (int i = 0; i < 8; i++) {
      if ((raw >> i) & 1) activeSensors++;
    }
  }

  // State machine logic
  switch (state) {

    
    case FOLLOWING_LINE: {
      // Obstacle detected, initiate avoidance
      if (obstacleAhead) {
        lastObstacleTime = millis();
        hw.motors.stop();
        state = SLIGHT_LEFT;
        stateStartTime = millis();
        break;
      }

      float error = lastError;

      // Line following logic
      if (lineFound && activeSensors <= 5) {
        
        if (raw & 0b10000000)      error = -4.0;
        else if (raw & 0b01000000) error = -2.5;
        else if (raw & 0b00110000) error = -1.0;
        else if (raw & 0b00011000) error = 0.0;
        else if (raw & 0b00001100) error = 1.0;
        else if (raw & 0b00000010) error = 2.5;
        else if (raw & 0b00000001) error = 4.0;

        // PID correction
        float correction = LINE_KP * error + LINE_KD * (error - lastError);
        correction = constrain(correction, -60, 60);

        // Dynamic base speed adjustment
        int baseSpeed = 135 - abs(error) * 15;
        baseSpeed = constrain(baseSpeed, 60, 150);

        // Calculate motor speeds
        int leftSpeed  = constrain(baseSpeed + correction, -80, 160);
        int rightSpeed = constrain(baseSpeed - correction, -80, 160);

        // Set motor speeds
        hw.motors.setSpeed(leftSpeed, rightSpeed * MOTOR_RIGHT_FACTOR);
        lastError = error;

      } else {
        // Line lost, spin in last known direction
        if (lastError > 0.5)       hw.motors.setSpeed(70, -70);
        else if (lastError < -0.5) hw.motors.setSpeed(-70, 70);
        else                       hw.motors.setSpeed(80, 80 * MOTOR_RIGHT_FACTOR);
      }
      break;
    }

   
    case SLIGHT_LEFT: {
      // Execute slight left turn
      if (millis() - stateStartTime < SLIGHT_TURN_TIME) {
        hw.motors.setSpeed(30, 80*MOTOR_RIGHT_FACTOR);  
      } else {
        hw.motors.stop();
        hw.encoderLeft.reset();
        hw.encoderRight.reset();
        state = BYPASS_FORWARD;
        stateStartTime = millis();
      }
      break;
    }

   
    case BYPASS_FORWARD: {
      unsigned long bypassElapsed = millis() - stateStartTime;

     // Move forward to bypass obstacle
      if (bypassElapsed < BYPASS_MAX_TIME) {
        hw.motors.setSpeed(80, 80 * MOTOR_RIGHT_FACTOR);
      } else {
        hw.motors.stop();
        state = SLIGHT_RIGHT;
        stateStartTime = millis();
      }
      break;
    }

   
    case SLIGHT_RIGHT: {
     // Execute slight right turn
      if (millis() - stateStartTime < (2*SLIGHT_TURN_TIME)) {
        hw.motors.setSpeed(80, 30*MOTOR_RIGHT_FACTOR);  
      } else {
        hw.motors.stop();
        state = ADVANCE_AFTER_RIGHT;
        stateStartTime = millis();
      }
      break;
    }

   
    case ADVANCE_AFTER_RIGHT: {
     
      unsigned long advanceElapsed = millis() - stateStartTime;
      // Move forward to clear obstacle area
      if (advanceElapsed < BYPASS_MAX_TIME) {
        hw.motors.setSpeed(80, 80 * MOTOR_RIGHT_FACTOR);
      } else {
        hw.motors.stop();
        state = SEARCHING_LINE;
        stateStartTime = millis();
      }
      break;
    }

    
    case SEARCHING_LINE: {
      unsigned long searchElapsed = millis() - stateStartTime;
      
    // Check for line detection
      if (lineFound && activeSensors >= 2) {
        
        hw.motors.stop();
        state = FOLLOWING_LINE;
        
       // Determine last error based on sensor readings
        if (raw & 0b11110000) lastError = -2.0;      
        else if (raw & 0b00001111) lastError = 2.0;  
        else lastError = 0;
        break;
      }

      // Timeout searching for line
      if (searchElapsed > SEARCH_TIME) {
        hw.motors.stop();
        break;
      }

      // Search pattern: alternate turning directions
      if (searchElapsed < SEARCH_TIME / 2) {
        hw.motors.setSpeed(80, -50);
      } else {
        hw.motors.setSpeed(100, 50);
      }
      break;
    }
  }
}


// ============================================
// MODE 3: TEST MOTORS BASIC
// ============================================
void modeTestMotorsBasic(Hardware& hw) {

  static unsigned long phaseStart = millis();
  unsigned long elapsed = millis() - phaseStart;
  
  // Each phase lasts 2000 ms
  if (elapsed < 2000)      
    hw.motors.forward(200);
  else if (elapsed < 2000) 
    hw.motors.backward(200);
  else if (elapsed < 6000) 
    hw.motors.turnLeft(150);
  else if (elapsed < 6000) 
    hw.motors.turnRight(150);
  else                     
    hw.motors.stop();
}

// ============================================
// MODE 4: FORWARD AND BACKWARD 30cm
// ============================================
void modeForwardBackward30cm(Hardware& hw) {
  static int state = 0;
  
  // State machine to move forward and backward 30 cm
  switch(state) {
    case 0:
      Serial.println(F("PHASE 1: Forward "));

      moveDistance(hw, 30.0, DEFAULT_SPEED, false); 

      Serial.print("Distance L:");
      Serial.print(hw.encoderLeft.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
      Serial.print("L ");
      Serial.print(hw.encoderLeft.getCount());
      Serial.print(" | Distance R:");
      Serial.print(hw.encoderRight.getDistance(WHEEL_DIAMETER_CM, ENCODER_PPR));
      Serial.print("R ");
      Serial.println(hw.encoderRight.getCount());

      state = 1;
      break;
    case 1:
      Serial.println(F("PHASE 2: Backward "));

      hw.motors.stop(); 
      moveBackwardDistance(hw, 30.0, DEFAULT_SPEED, false);
      state = 2;
      break;
    case 2:
      hw.motors.stop(); 
      break;
  }
}

// ============================================
// MODE 5: ROCKING
// ============================================
void modeRocking(Hardware& hw) {
  static unsigned long lastSwitch = 0;
  static bool direction = true;

  // Switch direction every 400 ms
  if (millis() - lastSwitch > 400) {
    if (direction)
     hw.motors.setSpeed(200, 200);
    else           
    hw.motors.setSpeed(-200, -200);
    
    direction = !direction;
    lastSwitch = millis();
  }
}

// ============================================
// MODE 6:  CALIBRATION
// ============================================
void modeCalibration(Hardware& hw) {
  static bool firstRun = true;
  // Run calibration only once
  if (firstRun) {

    Serial.println(F("Starting Line Sensor Calibration..."));
    hw.lineSensor.calibrate();
    
    Serial.println(F("Calibration Complete."));
    firstRun = false;
  }

  hw.motors.stop(); // Keep the robot stationary during calibration
}

// ============================================
// MODE 7: LINE FOLLOWING WTH OBSTACLE AVOIDANCE - STOP AND WAIT
// ============================================
void modeLineFollowingStopAndWait(Hardware& hw) {
 
  // State machine states
  static enum State {
    FOLLOWING_LINE,
    STOPPED_FOR_OBSTACLE
  } state = FOLLOWING_LINE;

  // Static variables for state management
  static float lastError = 0;

  // Constants
  const float OBSTACLE_DISTANCE = 10.0;  // cm 
 
  // Read sensors
  uint8_t raw = hw.lineSensor.readRaw();
  float distance = hw.sonar.measureDistance();

  // Obstacle detection
  bool obstacleAhead = (distance < OBSTACLE_DISTANCE && distance > 2.0);
  bool pathClear = (distance > OBSTACLE_DISTANCE || distance <= 2.0); 

  // Line sensor processing
  bool lineFound = (raw != 0);
  int activeSensors = 0;
  if (lineFound) {
    for (int i = 0; i < 8; i++) {
      if ((raw >> i) & 1) activeSensors++;
    }
  }

  // State machine logic
  switch (state) {

    case FOLLOWING_LINE: {
      // Check for obstacle
      if (obstacleAhead) {
        hw.motors.stop();
        state = STOPPED_FOR_OBSTACLE;
        break;
      }

      float error = lastError;

      // Line following logic
      if (lineFound && activeSensors <= 5) {
        
        // Calculate error based on sensor position
        if (raw & 0b10000000)      error = -4.0;
        else if (raw & 0b01000000) error = -2.5;
        else if (raw & 0b00110000) error = -1.0;
        else if (raw & 0b00011000) error = 0.0;
        else if (raw & 0b00001100) error = 1.0;
        else if (raw & 0b00000010) error = 2.5;
        else if (raw & 0b00000001) error = 4.0;

        // PID correction
        float correction = LINE_KP * error + LINE_KD * (error - lastError);
        correction = constrain(correction, -60, 60);

        // Dynamic base speed adjustment
        int baseSpeed = 130 - abs(error) * 15;
        baseSpeed = constrain(baseSpeed, 60, 150);

        // Calculate motor speeds
        int leftSpeed  = constrain(baseSpeed + correction, -80, 160);
        int rightSpeed = constrain(baseSpeed - correction, -80, 160);

        // Set motor speeds
        hw.motors.setSpeed(leftSpeed, rightSpeed * MOTOR_RIGHT_FACTOR);
        lastError = error;

      } else {
        // Line lost, spin in last known direction
        if (lastError > 0.5)       hw.motors.setSpeed(70, -70);
        else if (lastError < -0.5) hw.motors.setSpeed(-70, 70);
        else                       hw.motors.setSpeed(80, 80 * MOTOR_RIGHT_FACTOR);
      }
      break;
    }

    case STOPPED_FOR_OBSTACLE: {
      // Keep motors stopped
      hw.motors.stop();
      
      // Check if obstacle has been removed
      if (pathClear) {
        state = FOLLOWING_LINE;
        // Mantém o lastError para continuar na direção correta
      }
      break;
    }
  }
}

#endif