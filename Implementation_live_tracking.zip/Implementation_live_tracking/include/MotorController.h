/*
 * MotorController.h
 * Controls L298N motor driver for differential drive robot
 */

#ifndef MOTOR_CONTROLLER_H
#define MOTOR_CONTROLLER_H

#include <Arduino.h>

class MotorController {
private:
  uint8_t leftIn1, leftIn2;
  uint8_t rightIn1, rightIn2;
  
  // Set individual motor speed and direction
  void setMotor(uint8_t in1, uint8_t in2, int speed) {
    if (speed > 0) {
      analogWrite(in1, constrain(speed, 0, 255));
      digitalWrite(in2, LOW);
    } else if (speed < 0) {
      digitalWrite(in1, LOW);
      analogWrite(in2, constrain(-speed, 0, 255));
    } else {
      digitalWrite(in1, LOW);
      digitalWrite(in2, LOW);
    }
  }

public:
  MotorController(uint8_t l1, uint8_t l2, uint8_t r1, uint8_t r2): leftIn1(l1), leftIn2(l2), rightIn1(r1), rightIn2(r2) {}
  
  // Initialization
  void init() {
    pinMode(leftIn1, OUTPUT);
    pinMode(leftIn2, OUTPUT);
    pinMode(rightIn1, OUTPUT);
    pinMode(rightIn2, OUTPUT);
    stop();
    Serial.println("[Motor] Initialized");
  }
  
  // Set speed for both motors
  void setSpeed(int leftSpeed, int rightSpeed) {
    setMotor(leftIn1, leftIn2, leftSpeed);
    setMotor(rightIn1, rightIn2, rightSpeed);
  }
  
  // Basic movement commands
  void forward(int speed = 150) {
    setSpeed(speed, speed);
  }
  
  // Move backward
  void backward(int speed = 150) {
    setSpeed(-speed, -speed);
  }
  
  // Turn left
  void turnLeft(int speed = 100) {
    setSpeed(-speed, speed);
  }
  
  // Turn right
  void turnRight(int speed = 100) {
    setSpeed(speed, -speed);
  }
  
  // Stop both motors
  void stop() {
    setSpeed(0, 0);
  }
};

#endif