/**
 *  HardwareSetup.h
 *  Hardware abstraction layer and initialization
 */

#ifndef HARDWARE_SETUP_H
#define HARDWARE_SETUP_H

#include "MotorController.h"
#include "LineSensor.h"
#include "Sonar.h"
#include "IMU.h"
#include "Encoder.h"
#include "Config.h"


struct Hardware {
  // ============================================
  // HARDWARE COMPONENT INSTANCES
  // ============================================
  MotorController motors;      ///< Differential drive motor controller
  LineSensor lineSensor;       ///< IR line sensor array
  Sonar sonar;                 ///< Ultrasonic distance sensor
  IMU imu;                     ///< Inertial measurement unit
  Encoder encoderLeft;         ///< Left wheel encoder
  Encoder encoderRight;        ///< Right wheel encoder
  
 // Constructor
  Hardware():
      motors(MOTOR_L_IN1, MOTOR_L_IN2, MOTOR_R_IN3, MOTOR_R_IN4),
      lineSensor(LINE_PINS, 8, LINE_IR_ENABLE),
      sonar(SONAR_TRIG, SONAR_ECHO),
      imu(IMU_SDA, IMU_SCL),
      encoderLeft(ENCODER_L_A, ENCODER_L_B),
      encoderRight(ENCODER_R_A, ENCODER_R_B)
  {}
  
// Initialization routine
  void initialize() {
    Serial.println(F("\n┌─────────────────────────────────┐"));
    Serial.println(F("│  Hardware Initialization        │"));
    Serial.println(F("└─────────────────────────────────┘"));
    
    motors.init();
    lineSensor.init();
    sonar.init();
    imu.init();
    encoderLeft.init();
    encoderRight.init();
    
    Serial.println(F("\n✓ All subsystems operational\n"));
  }


  // Diagnostic routine
  void diagnosticCheck() {
    Serial.println(F("\n╔═══════════════════════════════╗"));
    Serial.println(F("║  Hardware Diagnostic Test     ║"));
    Serial.println(F("╚═══════════════════════════════╝\n"));
    
    // Motor subsystem test
    Serial.print(F("Motor Controller: "));
    motors.forward(100);
    delay(100);
    motors.stop();
    Serial.println(F("PASS"));
    
    // Encoder subsystem test
    Serial.print(F("Encoders: L="));
    Serial.print(encoderLeft.getCount());
    Serial.print(F(" R="));
    Serial.print(encoderRight.getCount());
    Serial.println(F(" PASS"));
    
    // Line sensor test
    Serial.print(F("Line Sensor Position: "));
    int linePos = lineSensor.readPosition();
    Serial.print(linePos);
    Serial.println(linePos == -1 ? F(" (no line)") : F(" PASS"));
    
    // Sonar test
    Serial.print(F("Sonar Distance: "));
    float distance = sonar.measureDistance();
    Serial.print(distance, 1);
    Serial.println(F(" cm PASS"));
    
    // IMU test
    Serial.print(F("IMU Yaw: "));
    Serial.print(imu.getYaw(), 2);
    Serial.println(F("° PASS"));
    
    Serial.println(F("\n✓ Diagnostic complete\n"));
  }
  
  // Reset both encoders
  void resetEncoders() {
    encoderLeft.reset();
    encoderRight.reset();
  }
  
  // Emergency stop routine
  void emergencyStop() {
    motors.stop();
    Serial.println(F("\n⚠ EMERGENCY STOP ACTIVATED\n"));
  }
};

#endif 