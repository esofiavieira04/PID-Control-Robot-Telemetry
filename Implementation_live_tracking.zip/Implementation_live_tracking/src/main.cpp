/**
 *  main.cpp
 *  Line Following Robot - Modular Architecture
 */

#include <Arduino.h>
#include "Config.h"
#include "HardwareSetup.h"
#include "Modes.h"
#include "LiveTracking.h"

// ============================================
// GLOBAL INSTANCES
// ============================================
Hardware hw;  ///< Hardware abstraction instance
LiveTracking telemetry;

// ============================================
// FUNCTION PROTOTYPES
// ============================================
void printWelcomeMessage();
bool needsCalibration(int mode);
void printCurrentMode(int mode);

/**
 * System initialization routine
 * 
 * Initializes serial communication, hardware subsystems,
 * and performs mode-specific setup procedures.
 */

void setup() {
  // Serial initialization
  Serial.begin(115200);
  hw.initialize();
  hw.encoderLeft.init();
  hw.encoderRight.init();
 telemetry.init();

  // Conditional calibration based on operational mode
  if (needsCalibration(ROBOT_MODE)) {
    hw.lineSensor.calibrate();
  }
  
  printCurrentMode(ROBOT_MODE);
  delay(1000);
}

/**
 * Main execution loop
 * 
 * Continuously updates IMU data and executes the selected
 * operational mode state machine.
 */

void loop() {
  
  static uint8_t webCounter = 0; // Counter to limit web handling frequency
  hw.imu.update(); // Update IMU data
telemetry.update();
  printWelcomeMessage();
  Serial.print("L: "); Serial.print(hw.encoderLeft.getCount());
  Serial.print(" | R: "); Serial.println(hw.encoderRight.getCount());

  // Mode selection state machine
  switch (ROBOT_MODE) {
    case 0:  modeDiagnostic(hw);           break;
    case 1:  modeLineFollow(hw);           break;
    case 2: modeLineFollowingWithObstacles(hw); break;
    case 3:  modeTestMotorsBasic(hw);      break;
    case 4:  modeForwardBackward30cm(hw);  break;
    case 5: modeRocking(hw);              break;
    case 6: modeCalibration(hw);   break;
    case 7: modeLineFollowingStopAndWait(hw); break;

    default: 
      Serial.println("ERROR: Invalid mode selected");
      modeDiagnostic(hw);
      break;
  }
}

// ============================================
// UTILITY FUNCTION IMPLEMENTATIONS
// ============================================

/**
 *  Displays system initialization banner
 * 
 * Outputs system version, architecture info, and current
 * configuration parameters to serial console.
 */
void printWelcomeMessage() {
  Serial.println(F("\n╔══════════════════════════════════╗"));
  Serial.println(F("║   Robot Controller               ║"));
  Serial.println(F("║   Moduler  Architecture          ║"));
  Serial.println(F("╚══════════════════════════════════╝\n"));
  
  Serial.print(F("Wheel Diameter: ")); 
  Serial.print(WHEEL_DIAMETER_CM, 2); 
  Serial.println(F(" cm"));
  
  Serial.print(F("Encoder Resolution: ")); 
  Serial.print(ENCODER_PPR);
  Serial.println(F(" PPR"));
  
  Serial.print(F("Build Date: "));
  Serial.print(F(__DATE__));
  Serial.print(F(" "));
  Serial.println(F(__TIME__));
  Serial.println();
}

/**
 *  Determines if line sensor calibration is required
 * 
 *  mode: Current operational mode
 *  true if calibration needed, false otherwise
 */
bool needsCalibration(int mode) {
  return (mode == 1 || mode == 2 || mode == 9);
}

/**
 *  Displays current operational mode
 * 
 *  mode: Mode identifier (0-12)
 */
void printCurrentMode(int mode) {
  Serial.print(F("\n>>> OPERATIONAL MODE: "));
  
  switch(mode) {
    case 0:  Serial.println(F("DIAGNOSTIC"));              break;
    case 1:  Serial.println(F("LINE FOLLOWING"));          break;
    case 2:  Serial.println(F("LINE FOLLOWING WITH OBSTACLES")); break;
    case 3:  Serial.println(F("TEST MOTORS BASIC"));       break;
    case 4:  Serial.println(F("FORWARD AND BACKWARD 30cm")); break;
    case 5:  Serial.println(F("ROCKING"));                 break;
    case 6:  Serial.println(F("CALIBRATION"));             break;
    
    default: 
      Serial.print(F("INVALID ("));
      Serial.print(mode);
      Serial.println(F(")"));
      break;
  }
  
  Serial.println();
}